/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea5;

/**
 *
 * @author Fernando
 */
class Node
{
public int value,key ;
public Node left,right ;
public Node (int key,int value)
{
this.value = value ;
this.key=key;
this.left=null;
this.right=null;
}
}